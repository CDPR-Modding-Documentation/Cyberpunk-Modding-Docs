local settingsMainName = "Variants"
local settingsSubName = "My Build"
local defaultStates = {
    {
        ref = "$/wheeze/variants",
        variant = "decals",
        displayName = "Decals Overlay",
        state = true
    },
    {
        ref = "$/wheeze/variants",
        variant = "meshes",
        displayName = "Extra Meshes",
        state = false
    }
}

local config = require("config")
local switcher = {
    GameUI = require("GameUI"),
    states = defaultStates
}

function switcher:new()
    registerForEvent("onInit", function()
        config.tryCreateConfig("config.json", defaultStates)
        config.backwardComp("config.json", defaultStates)
        self.states = config.loadFile("config.json")

        if not Codeware then
            print("Codeware not found, please install it to use this mod")
            return
        end

        self.GameUI.OnSessionStart(function()
            for _, variant in pairs(self.states) do
                Game.GetWorldStateSystem():TogglePrefabVariant(CreateNodeRef(variant.ref), variant.variant, variant.state)
            end
        end)

        local nativeSettings = GetMod("nativeSettings")

        if not nativeSettings then
            print("[Better Car Crashes] Error: NativeSettings lib not found!")
            return
        end

        local path = "/" .. string.gsub(settingsMainName, " ", "_"):lower()
        local subPath = "/" .. string.gsub(settingsSubName, " ", "_"):lower()

        if not nativeSettings.pathExists(path) then
            nativeSettings.addTab(path, settingsMainName)
        end

        nativeSettings.addSubcategory(path .. subPath, settingsSubName)

        for key, variant in pairs(self.states) do
            nativeSettings.addSwitch(path .. subPath, variant.displayName, "Toggle the " .. variant.displayName .. " variant", variant.state, defaultStates[key].state, function(state)
                self.states[key].state = state
                config.saveFile("config.json", self.states)
                Game.GetWorldStateSystem():TogglePrefabVariant(CreateNodeRef(variant.ref), variant.variant, state)
            end)
        end
    end)

    return self
end

return switcher:new()