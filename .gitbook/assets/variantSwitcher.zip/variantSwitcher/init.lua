-- Display names of the settings in the nativeSettings tab
local settingsMainName = "Variants"
local settingsSubName = "My Build"

-- These will get turned into a string selector, allowing only one to be active at a time
local defaultMutuallyExclusiveVariants = {
    {
        ref = "$/wheeze/variants",
        displayName = "Base Variant",
        currentIndex = 1, -- Would be lightBase
        variants = {
            {
                variant = "lightBase",
                displayName = "Light Interior"
            },
            {
                variant = "darkBase",
                displayName = "Dark Interior"
            }
        }
    }
}

-- These will get turned into switches, allowing multiple to be active at a time
local defaultAdditiveVariants = {
    {
        ref = "$/wheeze/variants",
        variant = "decals",
        displayName = "Decals Overlay",
        state = true
    },
    {
        ref = "$/wheeze/variants",
        variant = "meshes",
        displayName = "Extra Meshes",
        state = false
    }
}

--- DO NOT EDIT BELOW THIS LINE ---

local defaultStates = { mutually = defaultMutuallyExclusiveVariants, additive = defaultAdditiveVariants }
local config = require("config")
local switcher = {
    GameUI = require("GameUI"),
    states = defaultStates
}

function switcher:new()
    registerForEvent("onInit", function()
        config.tryCreateConfig("config.json", defaultStates)
        config.backwardComp("config.json", defaultStates)
        self.states = config.loadFile("config.json")

        if not Codeware then
            print("Codeware not found, please install it to use this mod")
            return
        end

        self.GameUI.OnSessionStart(function()
            for _, variant in pairs(self.states.additive) do
                Game.GetWorldStateSystem():TogglePrefabVariant(CreateNodeRef(variant.ref), variant.variant, variant.state)
            end

            for index, selection in pairs(self.states.mutually) do
                for _, variant in pairs(selection.variants) do
                    Game.GetWorldStateSystem():TogglePrefabVariant(CreateNodeRef(selection.ref), variant.variant, index == selection.currentIndex)
                end
            end
        end)

        local nativeSettings = GetMod("nativeSettings")

        if not nativeSettings then
            print("[VariantSwitcher] Error: NativeSettings lib not found!")
            return
        end

        local path = "/" .. string.gsub(settingsMainName, " ", "_"):lower()
        local subPath = "/" .. string.gsub(settingsSubName, " ", "_"):lower()

        if not nativeSettings.pathExists(path) then
            nativeSettings.addTab(path, settingsMainName)
        end

        nativeSettings.addSubcategory(path .. subPath, settingsSubName)

        for key, selection in pairs(self.states.mutually) do
            local options = {}
            for _, variant in pairs(selection.variants) do
                table.insert(options, variant.displayName)
            end

            nativeSettings.addSelectorString(path .. subPath, selection.displayName, "Select one variant", options, selection.currentIndex, defaultMutuallyExclusiveVariants[key].currentIndex, function(value)
                self.states.mutually[key].currentIndex = value
                config.saveFile("config.json", self.states)

                for index, variant in pairs(selection.variants) do
                    Game.GetWorldStateSystem():TogglePrefabVariant(CreateNodeRef(selection.ref), variant.variant, index == value)
                end
            end)
        end

        for key, variant in pairs(self.states.additive) do
            nativeSettings.addSwitch(path .. subPath, variant.displayName, "Toggle the " .. variant.displayName .. " variant", variant.state, defaultAdditiveVariants[key].state, function(state)
                self.states.additive[key].state = state
                config.saveFile("config.json", self.states)
                Game.GetWorldStateSystem():TogglePrefabVariant(CreateNodeRef(variant.ref), variant.variant, state)
            end)
        end
    end)

    return self
end

return switcher:new()