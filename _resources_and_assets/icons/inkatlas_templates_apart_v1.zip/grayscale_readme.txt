The grayscale layer in the .pdn (Paint (dot) NET files) is an optional layer to help reduce jagged edges around icons.
To use this, do the following:

1. Select all icons and copy them
2. Select the "Grayscale" layer and paste them
3. Under "Adjustments", open "Hue/Saturation" and set the "Lightness" value to -100.
4. Export the image as a 32-bit .png image with "Interlaced" enabled.